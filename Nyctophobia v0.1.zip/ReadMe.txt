v 0.1 update:
for now, ice ball does not have change in stat on level over 1. This will be updated on further version.
Keys:
Movement: WASD
Turn on/off the candle: Space Bar
Item Selection: mouse left click